hello server
I'm the client
I'm packeted the server function!
I'm add the sock_init!
fix some problem
