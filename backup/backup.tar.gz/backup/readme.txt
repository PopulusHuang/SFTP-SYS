hello server
I'm the client
