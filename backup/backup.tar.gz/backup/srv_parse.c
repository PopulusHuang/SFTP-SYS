#include <stdio.h>
#include "../share/order.h"
#include "../share/account.h"
#define FILENAME_SIZE 100
/* parse client's order */
int parse_clnt(SSL *ssl,char order,sqlite3 *db)
{
	int n;	
	int ret = 0;
	n = is_order_exist(order);
	if (n < 0)
	{
		fprintf(stderr,"order is not exist!\n");
		return -1;
	}
	switch(n)
	{
		case   CIN:	 clnt_login(ssl,order,db);break;	
		case  CREG:	 clnt_register(ssl,order,db);break;
		case  CSCS:	 scan_files(ssl,order);break;
		case   CUP:  recv_file(ssl);break;
		case CDOWN:	 send_file(ssl);break;
		default:     fprintf(stderr,"null order!\n");	
					 	ret = -1;break;
	}
	return ret;
}
/* get account's name and password */
int get_account(SSL *ssl,char *order,ACK *ack,ACCOUNT *account)
{

	sprintf(ack->order,"0%s",order);
	SSL_write_pk(ssl,ack->order,ORDER_SIZE);
	/* get the account data */
	SSL_read_pk(ssl,ack->data,DATA_SIZE);
	fetch_name(ack->data,user->name);
	fetch_passwd(ack->data,user->passwd);
	return 0;
}
/* handle client' login */
int clnt_login(SSL *ssl,char *order,sqlite3 *db)
{
	ACK ack;
	ACCOUNT user;
	int n,ret;
	bzero(&ack,sizeof(ack));
	bzero(&user,sizeof(user));
#if 0
	sprintf(ack.order,"0%s",order);
	send_order(ack);

	SSL_read_pk(ssl,ack.data,DATA_SIZE);
	fetch_name(ack.data,user.name);
	fetch_passwd(ack.data,user.passwd);
#endif
    get_account(ssl,order,&ack,&account);
	n = verify_account(db,ack.name,ack.passwd);
	switch(n)
	{
		/* verify succeed */
		case USER_OK:	sprintf(ack.order,"1%s",order);	
						ret = 1;break;
		/* user not exist */
		case USER_ERROR: sprintf(ack.order,"2%s",order); 
						 ret = 2;break; 
		/* password error */
		case PASSWD_ERROR: sprintf(ack.order,"3%s",order); 
						   ret = 3;break;
		/* undefine error */
		default: sprintf(ack.order,"4%s",order);
				 ret = -1;break;
	}
	SSL_write_pk(ssl,ack.order,ORDER_SIZE);
	return ret;
}
/* handle client's register */
int clnt_register(SSL *ssl,char *order,sqlite3 *db)
{
	ACK ack;
	ACCOUNT user;
	int n,ret;
	bzero(&ack,sizeof(ack));
	bzero(&user,sizeof(user));
	/* get the name and password */
    get_account(ssl,order,&ack,&account);
	n = register_account(db,ack.name,ack.passwd);
	if(n == 0)	/* register succeed */
	{
		sprintf(ack.order,"1%s",order);	
		ret = 0;
	}
	else if(n == -1) /* account is already exist */
	{
		sprintf(ack.order,"2%s",order);	
		ret = -1;
	}
		SSL_write_pk(ssl,ack.order,ORDER_SIZE);
		return ret;
}
/* scan file and send the files' list to client */
int scan_files(SSL *ssl,char *order)
{
	ACK ack;
	FILE *list_stream 	/* point to file list stream */	
	char cmd[DATA_SIZE];
	bzero(&ack,sizeof(ack));
	/* insert '0' to order,notify client to receive data */
	sprintf(ack.order,"0%s",order);
	SSL_write_pk(ssl,ack.order,ORDER_SIZE); 
	/* read the path from client */
	SSL_read_pk(ssl,ack.data,DATA_SIZE);
	strcpy(cmd,ack.data);
	list_stream = popen(cmd,"r")	/* list current directory */	
	bzero(ack.data,sizeof(ack.data));
	/* send the result to client */
	while(fgets(ack.data,DATA_SIZE-1,list_stream) != NULL)
	{
		if(SSL_write_pk(ssl,ack.data,DATA_SIZE-1) < 0)	
		{
			return -1;	
		}
		bzero(ack.data,sizeof(ack.data));
	}
	pclose(list_stream);
	return 0;
}
/* receive clients' file */
int recv_file(SSL *ssl,char *order)
{
	int fd;
	char fpath[50]="client_file/";	/* receive file's path */
	ACK ack;

	bzero(&ack,sizeof(ack.data));
	sprintf(ack.order,"0%s",order);
	SSL_write_pk(ssl,ack.order,ORDER_SIZE);

	/* start to receive file */
	fd = create_emptyfile(ssl,fpath,ack.data);
	write_data(ssl,ack.data,fd);
	close(fd);
	return 0;
}
/* send file to client */
int send_file(SSL *ssl,char *order)
{
	ACK ack;	
	char filename[FILENAME_SIZE+1];
	int fd;	
	int ret = 0;
	bzero(&ack,sizeof(ack));
	bzero(filename,sizeof(filename));
	/* get the file name */	
	SSL_read_pk(ssl,filename,FILENAME_SIZE);
	fd = open(filename,O_RDONLY);	
	if(fd < 0)
	{
		perror("open");	
		sprintf(ack.order,"2%s",order);
		ret = -1;
	}
	else
	{
		sprintf(ack.order,"0%s",order);	
	}
		SSL_write_pk(ssl,ack.order,ORDER_SIZE);
		/* copy the file to client */
	while(Read(fd,ack.data,DATA_SIZE) > 0)
	{
		SSL_write_pk(ssl,ack.data,DATA_SIZE);	
	}
		return ret;
}
