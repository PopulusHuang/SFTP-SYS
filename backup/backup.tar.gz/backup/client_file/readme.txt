hello server
I'm the client
fix some problem
